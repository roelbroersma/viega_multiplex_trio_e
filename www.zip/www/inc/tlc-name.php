<?php

	echo get_device_name();
?>
