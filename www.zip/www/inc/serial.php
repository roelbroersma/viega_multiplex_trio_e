<?php
	include("/www/inc/functions.php");

	echo read_serial('127.0.0.1');
?>
