<?php
	echo read_version();
?>

